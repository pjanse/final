const firebaseConfig = {
    apiKey: "AIzaSyCDqlMihxrCZ9yWrDIq7m4-snqKRxfP7Hk",
    authDomain: "frameworks-final.firebaseapp.com",
    databaseURL: "https://frameworks-final.firebaseio.com",
    projectId: "frameworks-final",
    storageBucket: "frameworks-final.appspot.com",
    messagingSenderId: "621333152329",
    appId: "1:621333152329:web:68963af3195e489f17b598",
    measurementId: "G-GK2XXB865W"
  };

  export default firebaseConfig;